<template>
  <div>
    <section id="contact" class="contact bg-primary">
        <div class="container">
            <h2><span>We&nbsp;</span><i class="fas fa-heart" style="color:#d73925"></i><span>&nbsp;new friends!</span></h2>
            <ul class="list-inline list-social">
                <li class="list-inline-item social-twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li class="list-inline-item social-facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li class="list-inline-item social-google-plus"><a href="#"><i class="fab fa-google-plus"></i></a></li>
            </ul>
        </div>
    </section>
    <footer>
        <div class="container">
            <p>©&nbsp;Rideshare by Relecloud. All Rights Reserved.</p>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="#">Privacy</a></li>
                <li class="list-inline-item"><a href="#">Terms</a></li>
                <li class="list-inline-item"><a href="#">FAQ</a></li>
            </ul>
        </div>
    </footer>
  </div>
</template>
