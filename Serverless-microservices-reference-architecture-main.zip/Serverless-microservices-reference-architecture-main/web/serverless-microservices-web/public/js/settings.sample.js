// Auth
window.authClientId = '';
window.authAuthority = '';
window.authScopes = [''];
window.authEnabled = false;

// API endpoints
window.apiKey = '';
window.apiBaseUrl = '';
window.apiDriversBaseUrl = `${window.apiBaseUrl}/d`;
window.apiTripsBaseUrl = `${window.apiBaseUrl}/t`;
window.apiPassengersBaseUrl = `${window.apiBaseUrl}/p`;
window.signalrInfoUrl = '';
